*********************************************************************************************
Please note:-
The firmware included in this download package is pre-configured to support the following

1)  1.5G/s, 3G/s, 6G/s SAS HDD.
2)  1.5G/s and 3G/s SATA HDD.

This firmware does not support/negotiate with 6G/s SATA HDD.

**********************************************************************************************
This download package contains BIOS and 
firmware images for a specific LSI Host 
Bus Adapter (HBA).  Please upgrade both 
the BIOS and the firmware together at the 
same time.  They are designed and tested 
only as matched sets.

Firmware images are included for 
both RAID and non-RAID applications.  
The RAID versions have an R in the 
filename.  The non-RAID versions have 
a T in the filename. The T stands 
for Initiator-Target.

The download package contains images 
for all chip revisions this board was 
ever sold with.  

A DOS installer is included in this 
download package.   A batch file 
called HBAFlash.bat is also included 
to simplify installation.  

Other LSI installers may be used with 
the BIOS and firmware images contained 
in this package.  To use the other 
installers you must download two 
packages: this one and the installer of 
your choice.  
