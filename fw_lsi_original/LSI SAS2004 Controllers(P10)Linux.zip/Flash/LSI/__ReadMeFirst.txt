First step is to copy the sas2flash(5/8/9/10) you will be using to just plain sas2flash.

Note: If the card you are flashing is a LSI card you can select the (P10) sas2flash version, if it is a rebranded card with LSI chipset (IBM, etc...) and it fails you can try to use an older sas2flash version. Also technically the "-o" in the commandline is only needed when flashing a non LSI Branded card.
