#!/bin/bash
/root/mdcmd status | strings | grep "mdState=STOPPED" >/dev/null 2>&1
if [ $? != 0 ]
then
	echo "Array found STARTED, stop array before proceeding"
	exit
fi
echo -e "\n"
echo "Using SAS2116, Initator-Target (IT) firmware"
echo -e "\n"
echo "COMMANDLINE THAT WILL BE USED:"
echo "sas2flash -l FlashLog.txt -o -f 9201-16i_it.BIN -b MPTSAS2.ROM"
echo -e "\n"
read -p "Press Enter key to start, or CTRL-C to quit."
echo -e "\n"
echo "Proceeding to Flash & Log too FlashLog.txt"
echo "in the current directory"
echo -e "\n"
sas2flash -l FlashLog.txt -o -f 9201-16i_it.bin -b mptsas2.rom
